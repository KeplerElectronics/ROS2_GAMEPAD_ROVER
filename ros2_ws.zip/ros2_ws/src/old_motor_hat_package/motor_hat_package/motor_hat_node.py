from adafruit_motorkit import MotorKit
import board
import time
kit = MotorKit()

    
def main():

    # print('Hi from motor_hat_package.')
    kit.motor1.throttle = 1.0
    time.sleep(0.5)
    kit.motor1.throttle = 0

if __name__ == '__main__':
    main()
